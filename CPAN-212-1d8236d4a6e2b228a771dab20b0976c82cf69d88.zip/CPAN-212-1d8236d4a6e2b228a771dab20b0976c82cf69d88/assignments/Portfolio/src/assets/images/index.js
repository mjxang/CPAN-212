import hero from './hero.jpg'
import shoppers from './shoppers.svg'
import rexall from './rexall.svg'
import winners from './winners.svg'
import hospital from './hospital.svg'
import uniqlo from './uniqlo.svg'
import logo from './logo.svg'

export {
    hero,
    shoppers,
    rexall,
    winners,
    hospital,
    uniqlo,
    logo
}